## Notes

Thanks to [Maitan69](https://maitan69.itch.io/) for making this game.

## Controls

| Button | Action |
|--|--| 
|A|Jump|


